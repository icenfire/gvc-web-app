import * as React from "react"

import AppBarLeaderDate from "../Level1/AppBars/AppBarLeaderDate"

export default class LoginPage extends React.PureComponent {
  public render() {
    return (
      <React.Fragment>
        <AppBarLeaderDate />
      </React.Fragment>
    )
  }
}
